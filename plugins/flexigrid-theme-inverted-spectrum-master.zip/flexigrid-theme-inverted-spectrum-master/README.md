Flexigrid for jQuery - Theme Inverted Spectrum
=================================

This is a theme for the Flexigrid for jQuery
=================================

HOW TO USE:

1 - Copy to your project directory the content of CSS directory

2 - On your main file (ex: index.html) instead to call the flexigrid css pack (ex: flexigrid-pack.css), import the CSS file:
flexigrid-inverted-spectrum.css <link rel="stylesheet" type="text/css" href="../css/flexigrid-inverted-spectrum.css" />

3 - That's all.

=================================
Original project: https://github.com/paulopmx/Flexigrid

The Flexigrid license:

Flexigrid for jQuery -  v1.1
 
Copyright (c) 2008 Paulo P. Marinas (https://github.com/paulopmx/Flexigrid-for-jQuery)
Dual licensed under the MIT or GPL Version 2 licenses.
http://jquery.org/license

=================================

This theme license:
<a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/deed.en_US"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-sa/3.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/deed.en_US">Creative Commons Attribution-ShareAlike 3.0 Unported License</a>.